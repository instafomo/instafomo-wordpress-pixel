=== Instafomo WP Pixel ===
Contributors: instafomo
Tags: social proof, pixel, marketing
Requires at least: 5.0
Tested up to: 6.6
Stable tag: 1.0
Requires PHP: 7.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
The Instafomo WP Pixel plugin allows you to easily integrate Instafomo's pixel tracking into your WordPress website. Display real-time social proof notifications to boost your website's conversion rates.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/instafomo-wp-pixel` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Use the Instafomo Pixel screen to configure the plugin.

== Contact Us ==
For any issues or questions, please contact the Instafomo team at developers@instafomo.com. If you face any challenges or issues, please email us at support@instafomo.com.

== Changelog ==
= 1.0 =
* Initial release.
